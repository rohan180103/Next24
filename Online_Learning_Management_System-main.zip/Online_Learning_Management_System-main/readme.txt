
FOR THE PERSON WHO IS WATCHING MY PROJECT

1. INSTALL XAMPP

2"Online_Learning_Management_System"

3. Extract the file and copy "Online_Learning_Management_System" folder

4.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

5. Open PHPMyAdmin (http://localhost/phpmyadmin)

6. Create a database with name dblms

7. Import dblms.sql file(given inside the zip package in SQL file folder)

8.Run the script http://localhost/Online_Learning_Management_System


**LOGIN DETAILS** 

for user create or student

Admin can sign up

