1.XAMPP

2. Extract the file and copy "voting management system" folder

3.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name votesystem

6. Import votesystem.sql file(given inside the zip package in SQL file folder)



7. for admin :  http://localhost/votesystem/admin/

for admin
username  shrinivas
password  password

admin can add positions (president, vice president etc), admin can add new candidate.
admin can add new voters.

8. voter can do voting by Running the script http://localhost/votesystem  
  voter id and password for voter is already set by admin 

